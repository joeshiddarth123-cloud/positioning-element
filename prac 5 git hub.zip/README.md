# QuantumGrid - Flexbox Responsive Navigation Menu

Practicum 5 (CSS Flexbox). A QuantumGrid page with a responsive navigation bar
(Blog, Plans dropdown, Contact, Log in, Sign up) and a wrapping image gallery.

Open `index.html` in a browser to view it.

- `index.html` - page structure
- `style.css` - Flexbox layout and the mobile media query
- `images/` - gallery images
